#include <stm32f4xx.h>

#ifndef SERVO_H
#define SERVO_H

extern volatile uint8_t response[20];
extern volatile uint8_t request[20];


extern volatile uint8_t response_received;
extern volatile uint8_t response_error;

void servo_USART1_SendByte(uint8_t data);

uint8_t servo_get_checksum(int size);

void servo_enable_tx(void);
void servo_disable_rx_tx(void);
void servo_enable_rx(void);
void servo_clear_old_rx(void);


void servo_ping(uint8_t id);


void servo_set_position(uint8_t id, uint16_t position,
                        uint16_t time, uint16_t speed);
#endif