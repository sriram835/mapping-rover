#include "stm32f4xx.h"


void init_func(void){
	RCC->APB1ENR |= (1U << 21);
	RCC->AHB1ENR |= (1U << 1);
	
	GPIOB->MODER |= (2U << 16) | (2U << 18);
	GPIOB->PUPDR |= (1U << 16) | (1U << 18);
	
	GPIOB->OTYPER |= (1U << 8) | (1U << 9);
	GPIOB->OSPEEDR |= (2U << 16) | (2U << 18);
	
	GPIOB->AFR[1] |= (4U << 0) | (4U << 4);
	
	  /* Disable I2C while configuring */
    I2C1->CR1 &= ~(1U << 0);

    /*
     * APB1 = 42 MHz
     */
    I2C1->CR2 = 42;

    /*
     * Standard Mode, 100 kHz
     *
     * CCR = 42 MHz / (2 * 100 kHz)
     *     = 210
     */
    I2C1->CCR = 210;

    /*
     * Standard Mode:
     * TRISE = 42 + 1
     */
    I2C1->TRISE = 43;

    /* Enable I2C */
    I2C1->CR1 |= (1U << 0);
}

void I2C_start(){
	I2C1->CR1 |= (1U << 10);
	I2C1->CR1 |= (1U<<8);
	
	while (!(I2C1->SR1 & (1<< 0))){}
		
}

void I2C_write(uint8_t var){
	while(!(I2C1->SR1 & (1U << 7))){}
	I2C1->DR = var;
	while (!(I2C1->SR1 & (1<<2))){}
}

void I2C_send_addr(uint8_t addr, uint8_t read)
{
    I2C1->DR = (addr << 1) | read;

    while (!(I2C1->SR1 & (1U << 1))) {}

    /* Clear ADDR by reading SR1 followed by SR2 */
    volatile uint32_t temp;

    temp = I2C1->SR1;
    temp = I2C1->SR2;
}

uint8_t I2C_read_reg(uint8_t dev_addr, uint8_t reg)
{
    uint8_t data;

    /* START */
    I2C1->CR1 |= (1U << 8);

    while (!(I2C1->SR1 & (1U << 0))) {}

    /* Device address + WRITE */
    I2C1->DR = dev_addr << 1;

    while (!(I2C1->SR1 & (1U << 1))) {}

    /* Clear ADDR */
    volatile uint32_t temp;
    temp = I2C1->SR1;
    temp = I2C1->SR2;

    /* Send register address */
    while (!(I2C1->SR1 & (1U << 7))) {}

    I2C1->DR = reg;

    /* Wait until register byte has been transmitted */
    while (!(I2C1->SR1 & (1U << 2))) {}

    /* Repeated START */
    I2C1->CR1 |= (1U << 8);

    while (!(I2C1->SR1 & (1U << 0))) {}

    /* Device address + READ */
    I2C1->DR = (dev_addr << 1) | 1;

    while (!(I2C1->SR1 & (1U << 1))) {}

    /* Clear ADDR */
    temp = I2C1->SR1;
    temp = I2C1->SR2;

    /* Disable ACK because we're receiving one byte */
    I2C1->CR1 &= ~(1U << 10);

    /* STOP */
    I2C1->CR1 |= (1U << 9);

    /* Wait for received byte */
    while (!(I2C1->SR1 & (1U << 6))) {}

    data = I2C1->DR;

    /* Re-enable ACK */
    I2C1->CR1 |= (1U << 10);

    return data;
}

void I2C_stop(void){
	I2C1->CR1 |= (1U << 9);
}

void delay_ms(uint32_t ms)
{
    while (ms--)
    {
        /*
         * Approximately 1 ms at 84 MHz.
         * This is only a rough delay for testing.
         */
        for (volatile uint32_t i = 0; i < 21000; i++)
        {
        }
    }
}

volatile uint8_t model_id;
int main(void){

    init_func();

    model_id = I2C_read_reg(0x29, 0xC0);

    while(1)
    {
    }
	
}