#include "test.h"

int main(void){
	my_init();
	while (1){
		GPIOC->ODR ^= (1U << 13);
		for (int i = 0; i < 100000; i++);
	}
}